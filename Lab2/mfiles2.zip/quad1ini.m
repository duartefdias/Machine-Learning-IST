global x1i threshold maxiter anim;

x1i = -9;

threshold = .01;

maxiter = 1000;

anim = 1;

a = 1;

eta = .1;

