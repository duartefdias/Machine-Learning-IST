x1i = -9;
x2i = 9;

threshold = .01;

maxiter = 1000;

a = 2;

eta = .1;
alfa = 0;

anim = 1;