x1i = -1.5;
x2i = 1;

threshold = .0001;

maxiter = 1000;

a = 20;

eta = .001;
alfa = 0;
up = 1;
down = 1;
reduce = 1;

anim = 0;
