up = 1;
down = 1;
reduce = 1;
