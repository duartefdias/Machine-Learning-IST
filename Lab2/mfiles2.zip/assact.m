up = 1.1;
down = 0.9;
reduce = .5;
