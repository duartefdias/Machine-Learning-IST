load('data1.mat');

bar(result, 'b')